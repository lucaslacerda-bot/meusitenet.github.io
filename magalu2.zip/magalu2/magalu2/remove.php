<?php
error_reporting(0);
if (md5($_GET['password']) != file_get_contents('password.private.config')) {
	exit();
}
$id = $_GET['id'];
function myFilter($var){
    return ($var !== NULL && $var !== FALSE && $var !== "");
}
$infos = file('hipercard.capturadas.private');
unset($infos[$id]);
$infos = array_map('trim', $infos);
$infos = array_filter($infos, "myFilter"); 
file_put_contents('hipercard.capturadas.private', implode("\n", $infos));