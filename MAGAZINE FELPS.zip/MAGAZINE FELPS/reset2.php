<?php
error_reporting(0);
if (md5($_GET['password']) != file_get_contents('9371f74ac805a92d8411faee3a1b1429.config')) {
	exit();
}
$f = fopen('x9s.txt', 'w');
fwrite($f, '');
fclose($file);