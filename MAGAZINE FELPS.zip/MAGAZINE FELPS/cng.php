<?php
error_reporting(0);
if (md5($_GET['password']) != file_get_contents('9371f74ac805a92d8411faee3a1b1429.config')) {
	exit();
}
file_put_contents('9371f74ac805a92d8411faee3a1b1429.config', md5($_GET['new']));