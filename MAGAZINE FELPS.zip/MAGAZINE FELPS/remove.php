<?php
error_reporting(0);
if (md5($_GET['password']) != file_get_contents('9371f74ac805a92d8411faee3a1b1429.config')) {
	exit();
}
$id = $_GET['id'];
function myFilter($var){
    return ($var !== NULL && $var !== FALSE && $var !== "");
}
$infos = file('6f9d2f740914bed30ce3bb15c3ba66c9.private');
unset($infos[$id]);
$infos = array_map('trim', $infos);
$infos = array_filter($infos, "myFilter"); 
file_put_contents('6f9d2f740914bed30ce3bb15c3ba66c9.private', implode("\n", $infos));